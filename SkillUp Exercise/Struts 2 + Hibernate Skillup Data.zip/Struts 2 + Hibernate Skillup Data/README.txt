----------------------
INSTRUCTIONS
----------------------

The files mentioned below are mandatory for creating a Struts 2 + Hibernate 4.3 Project.
Download these files from the respective websites and add to the classpath of the project.


----------------------
Required Jar Files
----------------------

Hibernate :- /lib/required/antlr-2.7.7.jar
Hibernate :- /lib/required/dom4j-1.6.1.jar
Hibernate :- /lib/required/hibernate-commons-annotations-4.0.2.Final.jar
Hibernate :- /lib/required/hibernate-core-4.2.7.Final.jar
Hibernate :- /lib/required/hibernate-jpa-2.0-api-1.0.1.Final.jar
Hibernate :- /lib/required/javassist-3.18.1-GA.jar
Hibernate :- /lib/required/jboss-logging-3.1.0.GA.jar
Hibernate :- /lib/required/jboss-transaction-api_1.1_spec-1.0.1.Final.jar
Hibernate :- /lib/jpa/hibernate-entitymanager-4.2.7.Final.jar


Struts :- /lib/asm-x.x.jar
Struts :- /lib/asm-commons-x.x.jar
Struts :- /lib/asm-tree-x.x.jar
Struts :- /lib/commons-io-1.4.jar
Struts :- /lib/commons-lang3-3.1.jar
Struts :- /lib/commons-fileupload-1.3.jar
Struts :- /lib/freemarker-2.3.19.jar
Struts :- /lib/javassist-3.18.1-GA.jar
Struts :- /lib/ognl-X.X.X.jar
Struts :- /lib/struts2-core-2.3.8.jar
Struts :- /lib/xwork-core-2.3.8.jar
