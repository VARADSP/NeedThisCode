// 
//  Fugitive.m
//  iBountyHunter
//
//  Created by Dan Pilone on 10/25/09.
//  Copyright 2009 Dan Pilone All rights reserved.
//

#import "Fugitive.h"


@implementation Fugitive 

@dynamic captdate;
@dynamic captured;
@dynamic bounty;
@dynamic name;
@dynamic fugitiveID;
@dynamic desc;

@end
