//
//  RootViewController.h
//  DrinkMixer
//
//  Created by Tracey Pilone on 10/21/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

@interface RootViewController : UITableViewController {
	NSMutableArray* drinks;
}

@property (nonatomic, retain) NSMutableArray* drinks;
@end
