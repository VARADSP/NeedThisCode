/* 
*
* Drink Constants.h
* DrinkMixer
*
* Created by Tracey Pilone on 10/21/09
*
*/

#define NAME_KEY @"name"
#define INGREDIENTS_KEY @"ingredients"
#define DIRECTIONS_KEY @"directions"