//
//  CapturedListViewController.h
//  iBountyHunter
//
//  Created by Dan Pilone on 10/24/09.
//  Copyright 2009 Dan Pilone All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CapturedListViewController : UITableViewController <NSFetchedResultsControllerDelegate> {
	NSFetchedResultsController *resultsController;
}

@property (nonatomic, retain) NSFetchedResultsController *resultsController;

@end
